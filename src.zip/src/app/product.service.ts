import { Injectable } from '@angular/core';
import { Product } from './model/Product';
import { HttpClient, HttpHeaders } from '@angular/common/http';
const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  productStatus: boolean
  adminStatus: boolean
  public products: Product[]
  http: any;
  constructor() {
    this.productStatus = false
    this.products = []

   }
   addProduct(product: Product) {
    return this.http.post('http://localhost:8444/grocery/product/save', product, httpOptions)
  }
  getProduct()
  {
    return this.http.get('http://localhost:8444/grocery/product/all', httpOptions)
  }
}
