import { Product } from './../model/Product';
import { Category} from './../model/Category';

import { Component, OnInit, Input } from '@angular/core';

import { Router, Event, NavigationEnd } from '@angular/router';
import { ProductService } from './../product.service';
import { CategoryService } from '../category.service';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})

export class ProductComponent implements OnInit {

  product: Product
  categorys:Category[]
  successFlag: boolean
  errorFlag: boolean
  products: Product[]
  progressFlag: boolean
  
 
  constructor(public prodService: ProductService, public router: Router,public catService:CategoryService) {
    this.initProduct()
    this.products = []
    this.product = new Product()
    this.catService.getCategory()
    .subscribe((res: Category[]) => {
      if (res) {
        this.categorys = res
      }

      this.progressFlag = false

    })

  }

  ngOnInit() {
  }

  productSubmit(productForm) {

    this.successFlag = false
    this.errorFlag = false

    this.prodService.addProduct(this.product)
      .subscribe((res: Product) => {

        if (res !== null) {
          this.successFlag = true

          this.router.navigateByUrl('/product')
        }
        else {
          this.errorFlag = true

        }
      }, err => {
        console.log(err)
        this.errorFlag = true

      })

  }

  getProduct() {
    this.progressFlag = true
    this.prodService.getProduct()
      .subscribe((res: Product[]) => {
        console.log(res)
        if (res) {
          this.products = res
        }

        this.progressFlag = false

      })
  }
  

  initProduct() {


  }
  
}
